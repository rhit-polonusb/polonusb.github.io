package editortrees;

import editortrees.EditTree.BooleanContainer;

/**
 * A node in a height-balanced binary tree with rank. Except for the NULL_NODE,
 * one node cannot belong to two different trees.
 * 
 * @author Sam Polonus
 */
public class Node {

	enum Code {
		SAME, LEFT, RIGHT;

		// Used in the displayer and debug string
		public String toString() {
			switch (this) {
			case LEFT:
				return "/";
			case SAME:
				return "=";
			case RIGHT:
				return "\\";
			default:
				throw new IllegalStateException();
			}
		}
	}

	// The fields would normally be private, but for the purposes of this class,
	// we want to be able to test the results of the algorithms in addition to the
	// "publicly visible" effects

	char data;
	Node left, right; // subtrees
	int rank = 0; // inorder position of this node within its own subtree.
	Code balance;
	DisplayableNodeWrapper displayableNodeWrapper;

	// Feel free to add other fields that you find useful.
	// You probably want a NULL_NODE, but you can comment it out if you decide
	// otherwise.
	// The NULL_NODE uses the "null character", \0, as it's data and null children,
	// but they could be anything since you shouldn't ever actually refer to them in
	// your code.
	static final Node NULL_NODE = new Node('\0', null, null);
	// Node parent; You may want parent, but think twice: keeping it up-to-date
	// takes effort too, maybe more than it's worth.

	public Node(char data, Node left, Node right) {
		this.data = data;
		this.left = left;
		this.right = right;
		if (this.left != null)
			this.rank = left.rank + 1;
		else
			this.rank = -1;

		if ((left == NULL_NODE) == (right == NULL_NODE))
			this.balance = Code.SAME;
		else if (left == NULL_NODE)
			this.balance = Code.RIGHT;
		else
			this.balance = Code.LEFT;

		displayableNodeWrapper = new DisplayableNodeWrapper(this);
	}

	public Node(char data) {
		// Make a leaf
		this(data, NULL_NODE, NULL_NODE);
	}

	// Provided to you to enable testing, please don't change.
	int slowHeight() {
		if (this == NULL_NODE) {
			return -1;
		}
		return Math.max(left.slowHeight(), right.slowHeight()) + 1;
	}

	// Provided to you to enable testing, please don't change.
	public int slowSize() {
		if (this == NULL_NODE) {
			return 0;
		}
		return left.slowSize() + right.slowSize() + 1;
	}

	/**
	 * Recursively prints out the tree
	 * 
	 * @param b
	 */
	public void toString(StringBuilder b) {
		if (this == NULL_NODE)
			return;

		this.left.toString(b);
		b.append(this.data);
		this.right.toString(b);
	}

	// A class used to keep track of changes made to balance codes
	class ChangeContainer {
		Node node = null;
		boolean changed = false;

		public ChangeContainer(Node n, boolean b) {
			node = n;
			changed = b;
		}
	}

	/**
	 * Recursively moves to the correct index to place a new character
	 * 
	 * @param ch
	 * @param pos
	 * @return The Node to insert IP
	 */
	public ChangeContainer add(char ch, int pos, EditTree.IntContainer i) {
		if (this == NULL_NODE) {
			return new ChangeContainer(new Node(ch), true);

		} else if (this.rank >= pos) {
			ChangeContainer lower = this.left.add(ch, pos, i);
			this.left = lower.node;
			this.rank++;
			return updateCodeLeft(i, lower.changed);

		} else {
			ChangeContainer lower = this.right.add(ch, pos - this.rank - 1, i);
			this.right = lower.node; // only pos-rank values are left to check
			return updateCodeRight(i, lower.changed);
		}
	}

	/**
	 * Scans the changes made on a left branch, updating balance codes and initiating rotations
	 * 
	 * @param i
	 * @param c
	 * @return The Node IP and whether its balance code changed / a rotation occurred 
	 */
	private ChangeContainer updateCodeLeft(EditTree.IntContainer i, boolean c) {
		boolean changed = true;
		Node out = this;
		if ((this.left.balance == Code.SAME || !c) && this.left.left != this.left.right) {
			changed = false;
		} else if (this.balance == Code.SAME) {
			this.balance = Code.LEFT;
		} else if (this.balance == Code.RIGHT) {
			this.balance = Code.SAME;
		} else if (this.left.balance == Code.LEFT) {
			i.value += 1;
			out = singleRight();
		} else if (this.left.balance == Code.RIGHT) {
			i.value += 2;
			out = doubleRight();
		}
		return new ChangeContainer(out, changed);
	}

	/**
	 * Scans the changes made on a right branch, updating balance codes and initiating rotations
	 * 
	 * @param i
	 * @param c
	 * @return The Node IP and whether its balance code changed / a rotation occurred 
	 */
	public ChangeContainer updateCodeRight(EditTree.IntContainer i, boolean c) {
		boolean changed = true;
		Node out = this;
		if ((this.right.balance == Code.SAME || !c) && this.right.left != this.right.right) {
			changed = false;
		} else if (this.balance == Code.SAME) {
			this.balance = Code.RIGHT;
		} else if (this.balance == Code.LEFT) {
			this.balance = Code.SAME;
		} else if (this.right.balance == Code.RIGHT) {
			i.value += 1;
			out = singleLeft();
		} else if (this.right.balance == Code.LEFT) {
			i.value += 2;
			out = doubleLeft();
		}
		return new ChangeContainer(out, changed);
	}

	/**
	 * Performs a single right rotation.
	 * 
	 * @return The top Node of the rotation
	 */
	public Node singleRight() {
		Node temp = this.left;
		this.left = temp.right;
		temp.right = this;
		this.rank -= temp.rank + 1;

		temp.balance = Code.SAME;
		this.balance = Code.SAME;

		return temp;
	}

	/**
	 * Performs a single left rotation.
	 * 
	 * @return The top Node of the rotation
	 */
	public Node singleLeft() {
		Node temp = this.right;
		this.right = temp.left;
		temp.left = this;
		temp.rank += this.rank + 1;

		temp.balance = Code.SAME;
		this.balance = Code.SAME;

		return temp;
	}

	/**
	 * Performs a double left rotation.
	 * 
	 * @return The top Node of the rotation
	 */
	public Node doubleLeft() {
		Code bal = this.right.left.balance; // grab the previous balance to configure future balances
		this.right = this.right.singleRight();
		
		if (bal == Code.RIGHT || bal == Code.SAME) // configure the right based on the original right balance
			this.right.right.balance = Code.SAME;
		else
			this.right.right.balance = Code.RIGHT;
		
		Node out = singleLeft();
		
		if (bal == Code.LEFT || bal == Code.SAME) // configure the right based on the original right balance
			out.left.balance = Code.SAME;
		else
			out.left.balance = Code.LEFT;
		
		return out;
	}

	/**
	 * Performs a double right rotation.
	 * 
	 * @return The top Node of the rotation
	 */
	public Node doubleRight() {
		Code bal = this.left.right.balance; // grab the previous balance to configure future balances
		this.left = this.left.singleLeft();
		
		if (bal == Code.LEFT || bal == Code.SAME) // configure the left based on the original left balance
			this.left.left.balance = Code.SAME;
		else
			this.left.left.balance = Code.LEFT;
		
		Node out = singleRight();
		
		if (bal == Code.RIGHT || bal == Code.SAME) // configure the right based on the original right balance
			out.right.balance = Code.SAME;
		else
			out.right.balance = Code.RIGHT;
		
		return out;
	}

	/**
	 * Recursively prints the list of characters and their ranks
	 * 
	 * @param b
	 */
	public void toRankString(StringBuilder b) {
		if (this == NULL_NODE)
			return;
		b.append(this.data);
		b.append(this.rank);
		b.append(", ");
		this.left.toRankString(b);
		this.right.toRankString(b);
	}

	/**
	 * Recursively prints the list of characters, their ranks and their balance
	 * codes
	 * 
	 * @param b
	 */
	public void toDebugString(StringBuilder b) {
		if (this == NULL_NODE)
			return;
		b.append(this.data);
		b.append(this.rank);
		b.append(this.balance.toString());
		b.append(", ");
		this.left.toDebugString(b);
		this.right.toDebugString(b);
	}

	/**
	 * Recursively searches for a character at a given position
	 * 
	 * @param pos
	 * @return The found character
	 */
	public char get(int pos) {
		if (this.rank == pos)
			return this.data;
		else if (this.rank > pos)
			return this.left.get(pos);
		else
			return this.right.get(pos - this.rank - 1); // only pos-rank values are left to check
	}

	/**
	 * Recursively confirms the size and rank of the subtrees
	 * 
	 * @param b
	 * @return The size of the current subtree, or -2
	 */
	public int ranksMatchLeftSubtreeSize(BooleanContainer b) {
		if (b.value == false)
			return -2;
		else if (this == NULL_NODE)
			return 0;
		else {
			int temp = this.left.ranksMatchLeftSubtreeSize(b); // get the left tree size
			if (this.rank != temp) { // ensure that the condition is met
				b.value = false;
				return -2;
			}
			return temp + this.right.ranksMatchLeftSubtreeSize(b) + 1; // get the right tree size and return the sum
		}
	}
	
	/**
	 * Recursively confirms the height and balance code of the subtrees
	 * 
	 * @param b
	 * @return The height of the current subtree, or -2
	 */
	public int balanceCodesAreCorrect(BooleanContainer b) {
		if (b.value == false)
			return -2;
		else if (this == NULL_NODE)
			return -1;
		else {
			int left = this.left.balanceCodesAreCorrect(b); // get the left tree height
			int right = this.right.balanceCodesAreCorrect(b); // get the right tree height
			
			if (left > right && this.balance == Code.LEFT)
				return Math.max(left,right)+1; // return subtree height
			else if (right > left && this.balance == Code.RIGHT)
				return Math.max(left,right)+1; // return subtree height
			else if (left == right && this.balance == Code.SAME)
				return Math.max(left,right)+1; // return subtree height
			else {
				b.value = false;
				return -2;
			}
		}
	}
	
	/**
	 * Recursively calculates the height using balance codes
	 * 
	 * @return The height of the subtree
	 */
	public int fastHeight() {
		if (this == NULL_NODE)
			return -1;
		else if (this.balance == Code.LEFT)
			return this.left.fastHeight()+1;
		else
			return this.right.fastHeight()+1;
	}
	
	// Stores and mutates the data deleted and changes made.
	class DeleteContainer {
		public char out;
		public Node replace;
		public boolean changed;
		
		public DeleteContainer(Node r, char o, boolean c) {
			replace = r;
			out = o;
			changed = c;
		}
	}
	
	/**
	 * Recursively iterates down the tree in search of the Node to delete, then removes it
	 * @param i
	 * @param pos
	 * @return The DeleteContainer controlling rotations and replacement
	 */
	public DeleteContainer delete(EditTree.IntContainer i, int pos) {
		DeleteContainer send = new DeleteContainer(this, '\0', true);
		
		if (this.rank > pos) {
			DeleteContainer previous = this.left.delete(i, pos);
			this.left = previous.replace;
			this.rank--;
			send = updateDeleteCodeLeft(i, previous.changed);
			send.out = previous.out;
		} else if (this.rank < pos) {
			DeleteContainer previous = this.right.delete(i, pos - this.rank - 1);
			this.right = previous.replace;
			send = updateDeleteCodeRight(i, previous.changed);
			send.out = previous.out;
		} else if (this.right == NULL_NODE) {
			send.out = this.data;
			send.replace = this.left;
		} else {
			char out = this.data;
			DeleteContainer previous = this.right.delete(i, 0);
			this.right = previous.replace;
			this.data = previous.out;
			send = updateDeleteCodeRight(i, previous.changed);
			send.out = out;
		}
		
		return send;
	}
	
	/**
	 * Scans the changes made on a left branch, updating balance codes and initiating rotations
	 * 
	 * @param i
	 * @param c
	 * @return The Node IP and whether its balance code changed / a rotation occurred 
	 */
	public DeleteContainer updateDeleteCodeLeft(EditTree.IntContainer i, boolean c) {
		boolean changed = true;
		Node out = this;
		if (this.left.balance != Code.SAME || !c) {
			changed = false;
		} else if (this.balance == Code.SAME) {
			this.balance = Code.RIGHT;
		} else if (this.balance == Code.LEFT) {
			this.balance = Code.SAME;
		} else if (this.right.balance == Code.RIGHT) {
			i.value += 1;
			out = singleLeft();
		} else if (this.right.balance == Code.LEFT) {
			i.value += 2;
			out = doubleLeft();
		} else {
			i.value += 1;
			out = singleLeft();
			out.balance = Code.LEFT;
			this.balance = Code.RIGHT;
		}
		return new DeleteContainer(out, '\0', changed);
	}
	
	/**
	 * Scans the changes made on a right branch, updating balance codes and initiating rotations
	 * 
	 * @param i
	 * @param c
	 * @return The Node IP and whether its balance code changed / a rotation occurred 
	 */
	public DeleteContainer updateDeleteCodeRight(EditTree.IntContainer i, boolean c) {
		boolean changed = true;
		Node out = this;
		if (this.right.balance != Code.SAME || !c) {
			changed = false;
		} else if (this.balance == Code.SAME) {
			this.balance = Code.LEFT;
		} else if (this.balance == Code.RIGHT) {
			this.balance = Code.SAME;
		} else if (this.left.balance == Code.LEFT) {
			i.value += 1;
			out = singleRight();
		} else if (this.left.balance == Code.RIGHT){
			i.value += 2;
			out = doubleRight();
		} else {
			i.value += 1;
			out = singleRight();
			out.balance = Code.RIGHT;
			this.balance = Code.LEFT;
		}
		return new DeleteContainer(out, '\0', changed);
	}
	
	/**
	 * Recursively generates an in-order traversal of a subset of the tree.
	 * @param pos
	 * @param length
	 * @param b
	 */
	public void get_string(int pos, int length, StringBuilder b) {		
		if (this == NULL_NODE || length == 0) {
			return;
		} else if (this.rank >= pos && this.rank <= pos+length-1) { // index is contained
			this.left.get_string(pos, this.rank-pos, b);
			b.append(this.data);
			this.right.get_string(0, length-(this.rank-pos)-1, b);
		} else if (this.rank > pos) { // index is to the left
			this.left.get_string(pos, length, b);
		} else if (this.rank < pos+length-1) { // index is to the right
			this.right.get_string(pos-rank-1, length, b);
		}
	}

	public boolean hasLeft() {
		return this.left != NULL_NODE;
	}

	public boolean hasRight() {
		return this.right != NULL_NODE;
	}

	public boolean hasParent() {
		return false;
	}

	public Node getParent() {
		return NULL_NODE;
	}
}